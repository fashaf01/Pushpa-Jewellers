10 LUXURY CASIO WATCHES
Compiled 30 October 2026 from https://www.casio.com/in/watches/

HOW TO USE
Extract the complete ZIP, then open index.html for the offline visual catalog.
Each numbered watch folder contains details.txt, details.html, sources.txt and a photos folder with five JPEG images.

SELECTION
Three flagship MR-G watches and seven premium MT-G models, ordered by India MRP.
These are 10 distinct model references; several are color/material variants within the same series.
This is a curated premium selection, not a claim to contain the ten most expensive watches on the site.

CONTENTS
01  MRG-B5000B-1  |  MR-G  |  ₹ 3,50,000 MRP
02  MRG-B2000B-1A4  |  MR-G  |  ₹ 2,50,000 MRP
03  MRG-B2000R-1A  |  MR-G  |  ₹ 2,50,000 MRP
04  MTG-B4000BD-1A  |  MT-G  |  ₹ 1,10,000 MRP
05  MTG-B2000YBD-2A  |  MT-G  |  ₹ 1,09,995 MRP
06  MTG-B4000B-1A  |  MT-G  |  ₹ 1,00,995 MRP
07  MTG-B4000B-1A2  |  MT-G  |  ₹ 1,00,995 MRP
08  MTG-B4000-1A  |  MT-G  |  ₹ 99,995 MRP
09  MTG-B2000YST-1A  |  MT-G  |  ₹ 94,995 MRP
10  MTG-B3000DN-1A  |  MT-G  |  ₹ 89,995 MRP

PRICES AND SOURCES
All prices are Casio India MRP in Indian rupees, including all taxes, checked 30 October 2026.
Prices/specifications may change; current stock and discounts were not verified.
Every folder includes its official product-page URL and direct photo source URLs.
Descriptions are concise summaries of the official information. Product photos: Casio.

SMALLER FILE EDITION
PNG photos converted to JPEG at quality 90 with a white background.
Original image dimensions, all 50 photos and all watch details retained.
