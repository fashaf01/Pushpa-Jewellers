﻿YOUR SIX SELECTED CASIO WATCHES
W. A. De Silva & Co. — Sri Lanka
Checked 30 October 2026

Selection: All four on the top row of your screenshot, then the first two on the bottom row.

CONTENTS
1. MTP-1308D-1AVDF — LKR 19,475 — Top row, first
2. MTP-1308D-9AVDF — LKR 19,475 — Top row, second
3. MTP-1253SG-9ADF — LKR 21,525 — Top row, third
4. MTP-1192A-7ADF — LKR 24,600 — Top row, fourth
5. MTP-1375L-7AVDF — LKR 27,675 — Bottom row, first
6. MTP-1374D-1AVDF — LKR 28,700 — Bottom row, second

Each watch has its own numbered folder containing details.txt, details.html, sources.txt and photos/.
The original retailer listing provides one 600 × 600 pixel product photo per watch: six photos in total.
Prices, availability and SKU references come from W. A. De Silva. Additional technical specifications, where available, come from the linked Casio pages.
The two listings without confirmed manufacturer specifications retain the retailer details and visible design descriptions only.

Extract the ZIP and open index.html to browse.
Prices are in Sri Lankan rupees; prices and availability may change.
